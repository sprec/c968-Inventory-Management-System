﻿namespace c968_PA
{
    partial class ProductForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addProductLabel = new Label();
            addProductIDLabel = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            idTextBox = new TextBox();
            nameTextBox = new TextBox();
            invenTextBox = new TextBox();
            priceTextBox = new TextBox();
            minTextBox = new TextBox();
            maxTextBox = new TextBox();
            canidateLabel = new Label();
            canidateTextBox = new TextBox();
            searchPartButton = new Button();
            canidatePartDataGridView = new DataGridView();
            addButton = new Button();
            partsAssociatedLabel = new Label();
            partsAssociatedDataGridView = new DataGridView();
            saveButton = new Button();
            deleteButton = new Button();
            cancelButton = new Button();
            ((System.ComponentModel.ISupportInitialize)canidatePartDataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)partsAssociatedDataGridView).BeginInit();
            SuspendLayout();
            // 
            // addProductLabel
            // 
            addProductLabel.AutoSize = true;
            addProductLabel.Font = new Font("Segoe UI", 15F, FontStyle.Bold, GraphicsUnit.Point);
            addProductLabel.Location = new Point(75, 19);
            addProductLabel.Name = "addProductLabel";
            addProductLabel.Size = new Size(96, 28);
            addProductLabel.TabIndex = 0;
            addProductLabel.Text = "DEFAULT";
            // 
            // addProductIDLabel
            // 
            addProductIDLabel.AutoSize = true;
            addProductIDLabel.Location = new Point(45, 74);
            addProductIDLabel.Name = "addProductIDLabel";
            addProductIDLabel.Size = new Size(18, 15);
            addProductIDLabel.TabIndex = 1;
            addProductIDLabel.Text = "ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(165, 195);
            label2.Name = "label2";
            label2.Size = new Size(30, 15);
            label2.TabIndex = 2;
            label2.Text = "Max";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(35, 195);
            label3.Name = "label3";
            label3.Size = new Size(28, 15);
            label3.TabIndex = 3;
            label3.Text = "Min";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(30, 166);
            label4.Name = "label4";
            label4.Size = new Size(33, 15);
            label4.TabIndex = 4;
            label4.Text = "Price";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(12, 134);
            label5.Name = "label5";
            label5.Size = new Size(57, 15);
            label5.TabIndex = 5;
            label5.Text = "Inventory";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(30, 105);
            label6.Name = "label6";
            label6.Size = new Size(39, 15);
            label6.TabIndex = 6;
            label6.Text = "Name";
            // 
            // idTextBox
            // 
            idTextBox.Location = new Point(75, 71);
            idTextBox.Name = "idTextBox";
            idTextBox.Size = new Size(181, 23);
            idTextBox.TabIndex = 7;
            idTextBox.TabStop = false;
            // 
            // nameTextBox
            // 
            nameTextBox.Location = new Point(75, 102);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.Size = new Size(181, 23);
            nameTextBox.TabIndex = 8;
            nameTextBox.TabStop = false;
            nameTextBox.TextChanged += nameTextBox_TextChanged;
            // 
            // invenTextBox
            // 
            invenTextBox.Location = new Point(75, 131);
            invenTextBox.Name = "invenTextBox";
            invenTextBox.Size = new Size(181, 23);
            invenTextBox.TabIndex = 9;
            invenTextBox.TabStop = false;
            invenTextBox.TextChanged += invenTextBox_TextChanged;
            // 
            // priceTextBox
            // 
            priceTextBox.Location = new Point(75, 163);
            priceTextBox.Name = "priceTextBox";
            priceTextBox.Size = new Size(181, 23);
            priceTextBox.TabIndex = 10;
            priceTextBox.TabStop = false;
            priceTextBox.TextChanged += priceTextBox_TextChanged;
            // 
            // minTextBox
            // 
            minTextBox.Location = new Point(75, 192);
            minTextBox.Name = "minTextBox";
            minTextBox.Size = new Size(55, 23);
            minTextBox.TabIndex = 11;
            minTextBox.TabStop = false;
            minTextBox.TextChanged += minTextBox_TextChanged;
            // 
            // maxTextBox
            // 
            maxTextBox.Location = new Point(201, 192);
            maxTextBox.Name = "maxTextBox";
            maxTextBox.Size = new Size(55, 23);
            maxTextBox.TabIndex = 12;
            maxTextBox.TabStop = false;
            maxTextBox.TextChanged += maxTextBox_TextChanged;
            // 
            // canidateLabel
            // 
            canidateLabel.AutoSize = true;
            canidateLabel.Location = new Point(367, 74);
            canidateLabel.Name = "canidateLabel";
            canidateLabel.Size = new Size(100, 15);
            canidateLabel.TabIndex = 13;
            canidateLabel.Text = "All Canidate Parts";
            // 
            // canidateTextBox
            // 
            canidateTextBox.Location = new Point(496, 66);
            canidateTextBox.Name = "canidateTextBox";
            canidateTextBox.PlaceholderText = "ENTER PART ID ONLY";
            canidateTextBox.Size = new Size(181, 23);
            canidateTextBox.TabIndex = 14;
            canidateTextBox.TabStop = false;
            canidateTextBox.KeyPress += canidateTextBox_KeyPress;
            // 
            // searchPartButton
            // 
            searchPartButton.Location = new Point(683, 66);
            searchPartButton.Name = "searchPartButton";
            searchPartButton.Size = new Size(75, 23);
            searchPartButton.TabIndex = 15;
            searchPartButton.TabStop = false;
            searchPartButton.Text = "Search";
            searchPartButton.UseVisualStyleBackColor = true;
            searchPartButton.Click += searchPartButton_Click;
            // 
            // canidatePartDataGridView
            // 
            canidatePartDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            canidatePartDataGridView.EditMode = DataGridViewEditMode.EditProgrammatically;
            canidatePartDataGridView.Location = new Point(367, 95);
            canidatePartDataGridView.MultiSelect = false;
            canidatePartDataGridView.Name = "canidatePartDataGridView";
            canidatePartDataGridView.RowHeadersVisible = false;
            canidatePartDataGridView.RowTemplate.Height = 25;
            canidatePartDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            canidatePartDataGridView.Size = new Size(391, 120);
            canidatePartDataGridView.TabIndex = 16;
            canidatePartDataGridView.SelectionChanged += canidatePartDataGridView_SelectionChanged;
            // 
            // addButton
            // 
            addButton.Location = new Point(683, 221);
            addButton.Name = "addButton";
            addButton.Size = new Size(75, 23);
            addButton.TabIndex = 17;
            addButton.TabStop = false;
            addButton.Text = "Add";
            addButton.UseVisualStyleBackColor = true;
            addButton.Click += addButton_Click;
            // 
            // partsAssociatedLabel
            // 
            partsAssociatedLabel.AutoSize = true;
            partsAssociatedLabel.Location = new Point(367, 255);
            partsAssociatedLabel.Name = "partsAssociatedLabel";
            partsAssociatedLabel.Size = new Size(190, 15);
            partsAssociatedLabel.TabIndex = 18;
            partsAssociatedLabel.Text = "Parts Associated With This Product";
            // 
            // partsAssociatedDataGridView
            // 
            partsAssociatedDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            partsAssociatedDataGridView.Location = new Point(367, 273);
            partsAssociatedDataGridView.Name = "partsAssociatedDataGridView";
            partsAssociatedDataGridView.RowHeadersVisible = false;
            partsAssociatedDataGridView.RowTemplate.Height = 25;
            partsAssociatedDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            partsAssociatedDataGridView.Size = new Size(391, 120);
            partsAssociatedDataGridView.TabIndex = 19;
            partsAssociatedDataGridView.SelectionChanged += partsAssociatedDataGridView_SelectionChanged;
            // 
            // saveButton
            // 
            saveButton.Location = new Point(521, 399);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(75, 23);
            saveButton.TabIndex = 20;
            saveButton.TabStop = false;
            saveButton.Text = "Save";
            saveButton.UseVisualStyleBackColor = true;
            saveButton.Click += saveButton_Click;
            // 
            // deleteButton
            // 
            deleteButton.Location = new Point(602, 399);
            deleteButton.Name = "deleteButton";
            deleteButton.Size = new Size(75, 23);
            deleteButton.TabIndex = 21;
            deleteButton.TabStop = false;
            deleteButton.Text = "Delete";
            deleteButton.UseVisualStyleBackColor = true;
            deleteButton.Click += deleteButton_Click;
            // 
            // cancelButton
            // 
            cancelButton.Location = new Point(683, 399);
            cancelButton.Name = "cancelButton";
            cancelButton.Size = new Size(75, 23);
            cancelButton.TabIndex = 22;
            cancelButton.TabStop = false;
            cancelButton.Text = "Cancel";
            cancelButton.UseVisualStyleBackColor = true;
            cancelButton.Click += cancelButton_Click;
            // 
            // ProductForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(cancelButton);
            Controls.Add(deleteButton);
            Controls.Add(saveButton);
            Controls.Add(partsAssociatedDataGridView);
            Controls.Add(partsAssociatedLabel);
            Controls.Add(addButton);
            Controls.Add(canidatePartDataGridView);
            Controls.Add(searchPartButton);
            Controls.Add(canidateTextBox);
            Controls.Add(canidateLabel);
            Controls.Add(maxTextBox);
            Controls.Add(minTextBox);
            Controls.Add(priceTextBox);
            Controls.Add(invenTextBox);
            Controls.Add(nameTextBox);
            Controls.Add(idTextBox);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(addProductIDLabel);
            Controls.Add(addProductLabel);
            Name = "ProductForm";
            Text = "PRODUCT";
            Load += ProductForm_Load;
            ((System.ComponentModel.ISupportInitialize)canidatePartDataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)partsAssociatedDataGridView).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label addProductLabel;
        private Label addProductIDLabel;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private TextBox idTextBox;
        private TextBox nameTextBox;
        private TextBox invenTextBox;
        private TextBox priceTextBox;
        private TextBox minTextBox;
        private TextBox maxTextBox;
        private Label canidateLabel;
        private TextBox canidateTextBox;
        private Button searchPartButton;
        private DataGridView canidatePartDataGridView;
        private Button addButton;
        private Label partsAssociatedLabel;
        private DataGridView partsAssociatedDataGridView;
        private Button saveButton;
        private Button deleteButton;
        private Button cancelButton;
    }
}