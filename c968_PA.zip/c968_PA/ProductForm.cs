﻿
using System.ComponentModel;
using System.Diagnostics;
using System.Xml.Linq;

namespace c968_PA
{
    public partial class ProductForm : Form
    {

        ToolTip checkMinMaxTip = new ToolTip();
        ToolTip addingTip = new ToolTip();
        ToolTip invenCheckTip = new ToolTip();
        private bool nameGood = false;
        private bool minMaxCheckGood = false;
        private bool maxGood = false;
        private bool minGood = false;
        private bool invGood = false;
        private bool decGood = false;
        private bool invenGood = false;
        public BindingList<Part> newParts4Product = new BindingList<Part>();





        public ProductForm()
        {
            InitializeComponent();
            canidatePartDataGridView.DataSource = Inventory.AllParts;
            addProductLabel.Text = "ADD PRODUCT";

            idTextBox.Text = Product.GenerateNewProductID().ToString();
            partsAssociatedDataGridView.DataSource = newParts4Product;

        }

        public ProductForm(Product product2Mod)
        {
            InitializeComponent();
            addProductLabel.Text = "MODIFY PRODUCT";
            canidatePartDataGridView.DataSource = Inventory.AllParts;
            partsAssociatedDataGridView.DataSource = product2Mod.AssociatedParts;

            idTextBox.Text = product2Mod.ProductID.ToString();
            nameTextBox.Text = product2Mod.Name;
            invenTextBox.Text = product2Mod.InStock.ToString();
            minTextBox.Text = product2Mod.Min.ToString();
            maxTextBox.Text = product2Mod.Max.ToString();
            priceTextBox.Text = product2Mod.Price.ToString();








        }

        private void ProductForm_Load(object sender, EventArgs e)
        {

            checkIntTextBox(invenTextBox);
            checkStringTextBox(nameTextBox);
            checkIntTextBox(maxTextBox);
            checkIntTextBox(minTextBox);
            checkDecimalTextBox(priceTextBox);
            canidatePartDataGridView.ClearSelection();
            partsAssociatedDataGridView.ClearSelection();
            idTextBox.Enabled = false;
            saveButton.Enabled = false;
            addButton.Enabled = false;
            deleteButton.Enabled = false;
        }






        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {
            nameGood = checkStringTextBox(nameTextBox);
            CheckEverything();
        }

        private void invenTextBox_TextChanged(object sender, EventArgs e)
        {
            invGood = checkIntTextBox(invenTextBox);
            invenGood = checkInven(invenTextBox);
            CheckEverything();


        }

        private void priceTextBox_TextChanged(object sender, EventArgs e)
        {
            decGood = checkDecimalTextBox(priceTextBox);
            CheckEverything();
        }

        private void minTextBox_TextChanged(object sender, EventArgs e)
        {
            minGood = checkIntTextBox(minTextBox);
            if (minGood && maxGood)
            {
                minMaxCheckGood = checkMinMax(maxTextBox, minTextBox);

            }
            CheckEverything();
        }

        private void maxTextBox_TextChanged(object sender, EventArgs e)
        {
            maxGood = checkIntTextBox(maxTextBox);
            invenGood = checkInven(invenTextBox);
            if (minGood && maxGood)
            {
                minMaxCheckGood = checkMinMax(maxTextBox, minTextBox);

            }
            CheckEverything();

        }

        private bool checkStringTextBox(TextBox stringTextBox)
        {
            if ((stringTextBox.Text.Length < 1) || int.TryParse(stringTextBox.Text, out _))
            {

                stringTextBox.BackColor = Color.Red;
                return false;
            }
            else
            {
                stringTextBox.BackColor = Color.LightBlue;
                return true;
            }


        }

        private bool checkIntTextBox(TextBox intTextBox)
        {
            if (int.TryParse(intTextBox.Text, out int parsedValue) && parsedValue >= 0)
            {
                intTextBox.BackColor = Color.LightBlue;
                return true;
            }
            else
            {
                intTextBox.BackColor = Color.Red;
                return false;
            }
        }

        private bool checkDecimalTextBox(TextBox priceCostTextBox)
        {
            if (decimal.TryParse(priceCostTextBox.Text, out _))
            {
                priceCostTextBox.BackColor = Color.LightBlue;
                return true;
            }
            else
            {
                priceCostTextBox.BackColor = Color.Red;
                return false;
            }

        }

        private bool checkMinMax(TextBox maxTextBox, TextBox minTextBox)
        {

            {
                int max = int.Parse(maxTextBox.Text);
                int min = int.Parse(minTextBox.Text);



                if (max > min)
                {
                    if (checkMinMaxTip.Active)
                    {
                        checkMinMaxTip.Hide(this);
                    }
                    return true;
                }
                else
                {
                    checkMinMaxTip.Show("Minimum must be LESS THAN max", this, 160, 350);
                    return false;
                }

            }
        }

        private void CheckEverything()
        {
            if (nameGood && invGood && decGood && minGood && maxGood && minMaxCheckGood && invenGood)
            {

                saveButton.Enabled = true;



            }
            else
            {
                saveButton.Enabled = false;

            }
        }



        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void PerformSearch(string enteredText)
        {
            try
            {


                Part partSearched = Inventory.LookupPart(int.Parse(canidateTextBox.Text));
                if (partSearched != null)
                {
                    int partSearchedID = partSearched.PartID;

                    foreach (DataGridViewRow row in canidatePartDataGridView.Rows)
                    {
                        if ((int)row.Cells["PartID"].Value == partSearchedID)
                        {
                            canidatePartDataGridView.Rows[row.Index].Selected = true;
                        }
                    }
                }



            }
            catch (FormatException)
            {
                MessageBox.Show("Format not correct, enter ID only", "Format Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
        }

        private void searchPartButton_Click(object sender, EventArgs e)
        {
            PerformSearch(canidateTextBox.Text);
        }

        private void canidateTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;

                PerformSearch(canidateTextBox.Text);

            }
        }

        private void addPart2Product()
        {

            try
            {
                DataGridViewRow rowSelected = canidatePartDataGridView.SelectedRows[0];
                Part canidate2Add = (Part)rowSelected.DataBoundItem;

                if (addProductLabel.Text == "ADD PRODUCT")
                {
                    newParts4Product.Add(canidate2Add);
                }
                else
                {
                    Product product2Add2 = Inventory.LookupProduct(int.Parse(idTextBox.Text));

                    product2Add2.AddAssociatedPart(canidate2Add);


                }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Nothing selected", "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
            }



        }

        private void addButton_Click(object sender, EventArgs e)
        {
            addPart2Product();
            addingTip.Show("Save Button not required for adding parts, continue with actions", this, 300, 250);
        }

        private void saveButton_Click(object sender, EventArgs e)
        {
            int id = int.Parse(idTextBox.Text);
            string name = nameTextBox.Text;
            decimal price = decimal.Parse(priceTextBox.Text);
            int inventory = int.Parse(invenTextBox.Text);
            int min = int.Parse(minTextBox.Text);
            int max = int.Parse(maxTextBox.Text);

            if (addProductLabel.Text == "ADD PRODUCT")
            {

                Product newProduct = new(newParts4Product, id, name, price, inventory, min, max);
                Save(newProduct);
            }
            else
            {
                int existingProductID = int.Parse(idTextBox.Text);
                Product existingProduct = Inventory.LookupProduct(existingProductID);

                Product newProduct = new(existingProduct.AssociatedParts, id, name, price, inventory, min, max);

                Save(existingProduct.ProductID, newProduct);


            }
            this.Close();
        }

        private void Save(Product newProduct)
        {
            Inventory.AddProduct(newProduct);
        }

        private void Save(int prod2Update, Product newProduct)
        {
            Inventory.UpdateProduct(prod2Update, newProduct);
        }

        private void canidatePartDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (canidatePartDataGridView.SelectedRows.Count > 0)
            {
                addButton.Enabled = true;
            }
            else
            {
                addButton.Enabled = false;
            }
        }
        private bool checkInven(TextBox inventoryTextBox)
        {
            if (int.TryParse(inventoryTextBox.Text, out _) && int.TryParse(maxTextBox.Text, out _))
            {
                if (int.Parse(inventoryTextBox.Text) <= int.Parse(maxTextBox.Text))
                {

                    if (invenCheckTip.Active)
                    {
                        invenCheckTip.Hide(this);
                    }

                    return true;
                }
                else
                {
                    invenCheckTip.Show("Inventory must be LESS THAN OR EQUAL TO max", this, 110, 350);
                    return false;
                }
            }
            else
            {
                return false;
            }

        }

        private void deleteButton_Click(object sender, EventArgs e)
        {
            DeletePart();
        }

        private void DeletePart()
        {


            deleteButton.Enabled = true;

            DataGridViewRow rowSelected = partsAssociatedDataGridView.SelectedRows[0];
            int part2Remove = (int)rowSelected.Cells[0].Value;

            Product product2RemoveFrom = Inventory.LookupProduct(int.Parse(idTextBox.Text));

            product2RemoveFrom.RemoveAssociatedPart(part2Remove);

        }

        private void partsAssociatedDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            if (partsAssociatedDataGridView.SelectedRows.Count > 0)
            {
                deleteButton.Enabled = true;
            }
            else
            {
                deleteButton.Enabled = false;
            }
        }
    }
}
