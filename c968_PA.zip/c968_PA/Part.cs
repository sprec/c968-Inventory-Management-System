﻿

namespace c968_PA
{
    public abstract class Part
    {
        protected static int currID = 0;

        public int PartID { get; set; }

        public string Name { get; set; }

        public decimal Price { get; set; }

        public int InStock { get; set; }

        public int Min { get; set; }

        public int Max { get; set; }


        public Part(int partID, string name, decimal price, int inStock, int min, int max)
        {
            this.PartID = partID;
            this.Name = name;
            this.Price = price;
            this.InStock = inStock;
            this.Min = min;
            this.Max = max;

        }

        public static int GenerateNewPartID()
        {
            return ++currID;
        }


    }
}
