﻿namespace c968_PA
{
    partial class addPartForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            addPartGroupBox = new GroupBox();
            outsourcedRadioButton = new RadioButton();
            inhouseRadioButton = new RadioButton();
            idTextBox = new TextBox();
            nameTextBox = new TextBox();
            inventoryTextBox = new TextBox();
            priceCostTextBox = new TextBox();
            idLabel = new Label();
            label2 = new Label();
            maxLabel = new Label();
            minLabel = new Label();
            priceCostLabel = new Label();
            inventoryLabel = new Label();
            nameLabel = new Label();
            minTextBox = new TextBox();
            maxTextBox = new TextBox();
            machineTextBox = new TextBox();
            saveButton = new Button();
            cancelButton = new Button();
            machineLabel = new Label();
            companyTextBox = new TextBox();
            companyLabel = new Label();
            addPartGroupBox.SuspendLayout();
            SuspendLayout();
            // 
            // addPartGroupBox
            // 
            addPartGroupBox.Anchor = AnchorStyles.Top;
            addPartGroupBox.Controls.Add(outsourcedRadioButton);
            addPartGroupBox.Controls.Add(inhouseRadioButton);
            addPartGroupBox.Location = new Point(83, 22);
            addPartGroupBox.Name = "addPartGroupBox";
            addPartGroupBox.Size = new Size(215, 53);
            addPartGroupBox.TabIndex = 0;
            addPartGroupBox.TabStop = false;
            addPartGroupBox.Text = "PART CLASSIFICATION";
            // 
            // outsourcedRadioButton
            // 
            outsourcedRadioButton.AutoSize = true;
            outsourcedRadioButton.Location = new Point(115, 21);
            outsourcedRadioButton.Name = "outsourcedRadioButton";
            outsourcedRadioButton.Size = new Size(87, 19);
            outsourcedRadioButton.TabIndex = 1;
            outsourcedRadioButton.TabStop = true;
            outsourcedRadioButton.Text = "Outsourced";
            outsourcedRadioButton.UseVisualStyleBackColor = true;
            outsourcedRadioButton.CheckedChanged += outsourcedRadioButton_CheckedChanged;
            // 
            // inhouseRadioButton
            // 
            inhouseRadioButton.AutoSize = true;
            inhouseRadioButton.Location = new Point(15, 21);
            inhouseRadioButton.Name = "inhouseRadioButton";
            inhouseRadioButton.Size = new Size(74, 19);
            inhouseRadioButton.TabIndex = 0;
            inhouseRadioButton.TabStop = true;
            inhouseRadioButton.Text = "In-House";
            inhouseRadioButton.UseVisualStyleBackColor = true;
            // 
            // idTextBox
            // 
            idTextBox.Location = new Point(83, 81);
            idTextBox.Name = "idTextBox";
            idTextBox.Size = new Size(215, 23);
            idTextBox.TabIndex = 2;
            //idTextBox.TextChanged += idTextBox_TextChanged;
            // 
            // nameTextBox
            // 
            nameTextBox.Location = new Point(83, 122);
            nameTextBox.Name = "nameTextBox";
            nameTextBox.Size = new Size(215, 23);
            nameTextBox.TabIndex = 3;
            nameTextBox.TextChanged += nameTextBox_TextChanged;
            // 
            // inventoryTextBox
            // 
            inventoryTextBox.Location = new Point(83, 161);
            inventoryTextBox.Name = "inventoryTextBox";
            inventoryTextBox.Size = new Size(74, 23);
            inventoryTextBox.TabIndex = 4;
            inventoryTextBox.TextChanged += inventoryTextBox_TextChanged;
            // 
            // priceCostTextBox
            // 
            priceCostTextBox.Location = new Point(83, 199);
            priceCostTextBox.Name = "priceCostTextBox";
            priceCostTextBox.Size = new Size(215, 23);
            priceCostTextBox.TabIndex = 5;
            priceCostTextBox.TextChanged += priceCostTextBox_TextChanged;
            // 
            // idLabel
            // 
            idLabel.AutoSize = true;
            idLabel.Location = new Point(59, 84);
            idLabel.Name = "idLabel";
            idLabel.Size = new Size(18, 15);
            idLabel.TabIndex = 6;
            idLabel.Text = "ID";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(39, 275);
            label2.Name = "label2";
            label2.Size = new Size(0, 15);
            label2.TabIndex = 7;
            // 
            // maxLabel
            // 
            maxLabel.AutoSize = true;
            maxLabel.Location = new Point(173, 238);
            maxLabel.Name = "maxLabel";
            maxLabel.Size = new Size(30, 15);
            maxLabel.TabIndex = 8;
            maxLabel.Text = "Max";
            // 
            // minLabel
            // 
            minLabel.AutoSize = true;
            minLabel.Location = new Point(46, 238);
            minLabel.Name = "minLabel";
            minLabel.Size = new Size(31, 15);
            minLabel.TabIndex = 9;
            minLabel.Text = "Min ";
            // 
            // priceCostLabel
            // 
            priceCostLabel.AutoSize = true;
            priceCostLabel.Location = new Point(12, 202);
            priceCostLabel.Name = "priceCostLabel";
            priceCostLabel.Size = new Size(68, 15);
            priceCostLabel.TabIndex = 10;
            priceCostLabel.Text = "Price / Cost";
            // 
            // inventoryLabel
            // 
            inventoryLabel.AutoSize = true;
            inventoryLabel.Location = new Point(20, 164);
            inventoryLabel.Name = "inventoryLabel";
            inventoryLabel.Size = new Size(57, 15);
            inventoryLabel.TabIndex = 11;
            inventoryLabel.Text = "Inventory";
            // 
            // nameLabel
            // 
            nameLabel.AutoSize = true;
            nameLabel.Location = new Point(39, 125);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new Size(39, 15);
            nameLabel.TabIndex = 12;
            nameLabel.Text = "Name";
            // 
            // minTextBox
            // 
            minTextBox.Location = new Point(83, 235);
            minTextBox.Name = "minTextBox";
            minTextBox.Size = new Size(74, 23);
            minTextBox.TabIndex = 13;
            minTextBox.TextChanged += minTextBox_TextChanged;
            // 
            // maxTextBox
            // 
            maxTextBox.Location = new Point(209, 235);
            maxTextBox.Name = "maxTextBox";
            maxTextBox.Size = new Size(89, 23);
            maxTextBox.TabIndex = 14;
            maxTextBox.TextChanged += maxTextBox_TextChanged;
            // 
            // machineTextBox
            // 
            machineTextBox.Location = new Point(83, 272);
            machineTextBox.Name = "machineTextBox";
            machineTextBox.Size = new Size(215, 23);
            machineTextBox.TabIndex = 15;
            machineTextBox.TextChanged += machineTextBox_TextChanged;
            // 
            // saveButton
            // 
            saveButton.Location = new Point(179, 342);
            saveButton.Name = "saveButton";
            saveButton.Size = new Size(75, 23);
            saveButton.TabIndex = 16;
            saveButton.Text = "Save";
            saveButton.UseVisualStyleBackColor = true;
            saveButton.Click += saveButton_Click;
            // 
            // cancelButton
            // 
            cancelButton.Location = new Point(260, 342);
            cancelButton.Name = "cancelButton";
            cancelButton.Size = new Size(75, 23);
            cancelButton.TabIndex = 17;
            cancelButton.Text = "Cancel";
            cancelButton.UseVisualStyleBackColor = true;
            cancelButton.Click += cancelButton_Click;
            // 
            // machineLabel
            // 
            machineLabel.AutoSize = true;
            machineLabel.Location = new Point(12, 275);
            machineLabel.Name = "machineLabel";
            machineLabel.Size = new Size(67, 15);
            machineLabel.TabIndex = 18;
            machineLabel.Text = "Machine ID";
            // 
            // companyTextBox
            // 
            companyTextBox.Location = new Point(83, 272);
            companyTextBox.Name = "companyTextBox";
            companyTextBox.Size = new Size(215, 23);
            companyTextBox.TabIndex = 19;
            companyTextBox.Visible = false;
            companyTextBox.TextChanged += companyTextBox_TextChanged;
            // 
            // companyLabel
            // 
            companyLabel.AutoSize = true;
            companyLabel.Location = new Point(18, 275);
            companyLabel.Name = "companyLabel";
            companyLabel.Size = new Size(59, 15);
            companyLabel.TabIndex = 20;
            companyLabel.Text = "Company";
            companyLabel.Visible = false;
            // 
            // addPartForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(366, 377);
            Controls.Add(companyLabel);
            Controls.Add(machineLabel);
            Controls.Add(cancelButton);
            Controls.Add(saveButton);
            Controls.Add(maxTextBox);
            Controls.Add(minTextBox);
            Controls.Add(nameLabel);
            Controls.Add(inventoryLabel);
            Controls.Add(priceCostLabel);
            Controls.Add(minLabel);
            Controls.Add(maxLabel);
            Controls.Add(label2);
            Controls.Add(idLabel);
            Controls.Add(priceCostTextBox);
            Controls.Add(inventoryTextBox);
            Controls.Add(nameTextBox);
            Controls.Add(idTextBox);
            Controls.Add(addPartGroupBox);
            Controls.Add(companyTextBox);
            Controls.Add(machineTextBox);
            Name = "addPartForm";
            Text = "ADD PART";
            Load += addPartForm_Load;
            addPartGroupBox.ResumeLayout(false);
            addPartGroupBox.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox addPartGroupBox;
        private RadioButton outsourcedRadioButton;
        private RadioButton inhouseRadioButton;
        private TextBox idTextBox;
        private TextBox nameTextBox;
        private TextBox inventoryTextBox;
        private TextBox priceCostTextBox;
        private Label idLabel;
        private Label label2;
        private Label maxLabel;
        private Label minLabel;
        private Label priceCostLabel;
        private Label inventoryLabel;
        private Label nameLabel;
        private TextBox minTextBox;
        private TextBox maxTextBox;
        private TextBox machineTextBox;
        private Button saveButton;
        private Button cancelButton;
        private Label machineLabel;
        private TextBox companyTextBox;
        private Label companyLabel;
    }
}