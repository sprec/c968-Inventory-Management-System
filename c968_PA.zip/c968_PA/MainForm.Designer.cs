﻿namespace c968_PA
{
    partial class MainForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            mainLabel = new Label();
            partLabels = new Label();
            Products = new Label();
            partTextBox = new TextBox();
            productTextBox = new TextBox();
            partSearch = new Button();
            productSearch = new Button();
            partAddButton = new Button();
            partDataGridView = new DataGridView();
            productDataGridView = new DataGridView();
            partsModifyButton = new Button();
            productDeleteButton = new Button();
            productModifyButton = new Button();
            productAddButton = new Button();
            deletePartButton = new Button();
            mainExitButton = new Button();
            outsourcedBindingSource = new BindingSource(components);
            outsourcedBindingSource1 = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)partDataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)productDataGridView).BeginInit();
            ((System.ComponentModel.ISupportInitialize)outsourcedBindingSource).BeginInit();
            ((System.ComponentModel.ISupportInitialize)outsourcedBindingSource1).BeginInit();
            SuspendLayout();
            // 
            // mainLabel
            // 
            mainLabel.AutoSize = true;
            mainLabel.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            mainLabel.Location = new Point(12, 9);
            mainLabel.Name = "mainLabel";
            mainLabel.Size = new Size(339, 25);
            mainLabel.TabIndex = 0;
            mainLabel.Text = "INVENTORY MANAGEMENT SYSTEM";
            // 
            // partLabels
            // 
            partLabels.AutoSize = true;
            partLabels.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            partLabels.Location = new Point(68, 75);
            partLabels.Name = "partLabels";
            partLabels.Size = new Size(58, 25);
            partLabels.TabIndex = 1;
            partLabels.Text = "Parts";
            // 
            // Products
            // 
            Products.AutoSize = true;
            Products.Font = new Font("Segoe UI", 14F, FontStyle.Bold, GraphicsUnit.Point);
            Products.Location = new Point(539, 76);
            Products.Name = "Products";
            Products.Size = new Size(92, 25);
            Products.TabIndex = 15;
            Products.Text = "Products";
            // 
            // partTextBox
            // 
            partTextBox.Location = new Point(68, 103);
            partTextBox.Name = "partTextBox";
            partTextBox.PlaceholderText = "ENTER PART ID ONLY";
            partTextBox.Size = new Size(207, 23);
            partTextBox.TabIndex = 2;
            partTextBox.TabStop = false;
            partTextBox.KeyPress += partTextBox_KeyPress;
            // 
            // productTextBox
            // 
            productTextBox.Location = new Point(539, 104);
            productTextBox.Name = "productTextBox";
            productTextBox.PlaceholderText = "ENTER PRODUCT ID ONLY";
            productTextBox.Size = new Size(193, 23);
            productTextBox.TabIndex = 14;
            productTextBox.TabStop = false;
            productTextBox.KeyPress += productTextBox_KeyPress;
            // 
            // partSearch
            // 
            partSearch.Location = new Point(281, 103);
            partSearch.Name = "partSearch";
            partSearch.Size = new Size(75, 23);
            partSearch.TabIndex = 3;
            partSearch.TabStop = false;
            partSearch.Text = "Search";
            partSearch.UseVisualStyleBackColor = true;
            partSearch.Click += partSearch_Click;
            // 
            // productSearch
            // 
            productSearch.Location = new Point(738, 104);
            productSearch.Name = "productSearch";
            productSearch.Size = new Size(75, 23);
            productSearch.TabIndex = 12;
            productSearch.TabStop = false;
            productSearch.Text = "Search";
            productSearch.UseVisualStyleBackColor = true;
            productSearch.Click += productSearch_Click;
            // 
            // partAddButton
            // 
            partAddButton.Location = new Point(68, 354);
            partAddButton.Name = "partAddButton";
            partAddButton.Size = new Size(75, 23);
            partAddButton.TabIndex = 5;
            partAddButton.TabStop = false;
            partAddButton.Text = "Add";
            partAddButton.UseVisualStyleBackColor = true;
            partAddButton.Click += partAddButton_Click;
            // 
            // partDataGridView
            // 
            partDataGridView.AllowUserToResizeRows = false;
            partDataGridView.BackgroundColor = SystemColors.Highlight;
            partDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            partDataGridView.EditMode = DataGridViewEditMode.EditProgrammatically;
            partDataGridView.Location = new Point(68, 132);
            partDataGridView.MultiSelect = false;
            partDataGridView.Name = "partDataGridView";
            partDataGridView.RowHeadersVisible = false;
            partDataGridView.RowTemplate.Height = 25;
            partDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            partDataGridView.Size = new Size(351, 208);
            partDataGridView.TabIndex = 4;
            partDataGridView.TabStop = false;
            partDataGridView.CellContentDoubleClick += partDataGridView_CellContentDoubleClick;
            // 
            // productDataGridView
            // 
            productDataGridView.AllowUserToResizeRows = false;
            productDataGridView.BackgroundColor = SystemColors.Highlight;
            productDataGridView.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            productDataGridView.EditMode = DataGridViewEditMode.EditProgrammatically;
            productDataGridView.Location = new Point(539, 129);
            productDataGridView.MultiSelect = false;
            productDataGridView.Name = "productDataGridView";
            productDataGridView.RowHeadersVisible = false;
            productDataGridView.RowTemplate.Height = 25;
            productDataGridView.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            productDataGridView.Size = new Size(368, 208);
            productDataGridView.TabIndex = 13;
            productDataGridView.TabStop = false;
            productDataGridView.CellContentDoubleClick += productDataGridView_CellContentDoubleClick;
            // 
            // partsModifyButton
            // 
            partsModifyButton.Location = new Point(149, 354);
            partsModifyButton.Name = "partsModifyButton";
            partsModifyButton.Size = new Size(75, 23);
            partsModifyButton.TabIndex = 6;
            partsModifyButton.TabStop = false;
            partsModifyButton.Text = "Modify";
            partsModifyButton.UseVisualStyleBackColor = true;
            partsModifyButton.Click += partsModifyButton_Click;
            // 
            // productDeleteButton
            // 
            productDeleteButton.Location = new Point(701, 354);
            productDeleteButton.Name = "productDeleteButton";
            productDeleteButton.Size = new Size(75, 23);
            productDeleteButton.TabIndex = 10;
            productDeleteButton.TabStop = false;
            productDeleteButton.Text = "Delete";
            productDeleteButton.UseVisualStyleBackColor = true;
            productDeleteButton.Click += productDeleteButton_Click;
            // 
            // productModifyButton
            // 
            productModifyButton.Location = new Point(620, 354);
            productModifyButton.Name = "productModifyButton";
            productModifyButton.Size = new Size(75, 23);
            productModifyButton.TabIndex = 9;
            productModifyButton.TabStop = false;
            productModifyButton.Text = "Modify";
            productModifyButton.UseVisualStyleBackColor = true;
            productModifyButton.Click += productModifyButton_Click;
            // 
            // productAddButton
            // 
            productAddButton.Location = new Point(539, 354);
            productAddButton.Name = "productAddButton";
            productAddButton.Size = new Size(75, 23);
            productAddButton.TabIndex = 8;
            productAddButton.TabStop = false;
            productAddButton.Text = "Add ";
            productAddButton.UseVisualStyleBackColor = true;
            productAddButton.Click += productAddButton_Click;
            // 
            // deletePartButton
            // 
            deletePartButton.Location = new Point(230, 354);
            deletePartButton.Name = "deletePartButton";
            deletePartButton.Size = new Size(75, 23);
            deletePartButton.TabIndex = 7;
            deletePartButton.TabStop = false;
            deletePartButton.Text = "Delete";
            deletePartButton.UseVisualStyleBackColor = true;
            deletePartButton.Click += deletePartButton_Click;
            // 
            // mainExitButton
            // 
            mainExitButton.Location = new Point(863, 422);
            mainExitButton.Name = "mainExitButton";
            mainExitButton.Size = new Size(75, 23);
            mainExitButton.TabIndex = 11;
            mainExitButton.TabStop = false;
            mainExitButton.Text = "EXIT";
            mainExitButton.UseVisualStyleBackColor = true;
            mainExitButton.Click += mainExitButton_Click;
            // 
            // outsourcedBindingSource
            // 
            outsourcedBindingSource.DataSource = typeof(Outsourced);
            // 
            // outsourcedBindingSource1
            // 
            outsourcedBindingSource1.DataSource = typeof(Outsourced);
            // 
            // MainForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(960, 457);
            Controls.Add(mainExitButton);
            Controls.Add(deletePartButton);
            Controls.Add(productAddButton);
            Controls.Add(productModifyButton);
            Controls.Add(productDeleteButton);
            Controls.Add(partsModifyButton);
            Controls.Add(productDataGridView);
            Controls.Add(partDataGridView);
            Controls.Add(partAddButton);
            Controls.Add(productSearch);
            Controls.Add(partSearch);
            Controls.Add(productTextBox);
            Controls.Add(partTextBox);
            Controls.Add(Products);
            Controls.Add(partLabels);
            Controls.Add(mainLabel);
            Name = "MainForm";
            Text = "INVENTORY MANAGEMENT SYSTEM";
            Load += MainForm_Load;
            ((System.ComponentModel.ISupportInitialize)partDataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)productDataGridView).EndInit();
            ((System.ComponentModel.ISupportInitialize)outsourcedBindingSource).EndInit();
            ((System.ComponentModel.ISupportInitialize)outsourcedBindingSource1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label mainLabel;
        private Label partLabels;
        private Label Products;
        private TextBox partTextBox;
        private TextBox productTextBox;
        private Button partSearch;
        private Button productSearch;
        private Button partAddButton;
        private DataGridView partDataGridView;
        private DataGridView productDataGridView;
        private Button partsModifyButton;
        private Button productDeleteButton;
        private Button productModifyButton;
        private Button productAddButton;
        private Button deletePartButton;
        private Button mainExitButton;
        private BindingSource outsourcedBindingSource;
        private BindingSource outsourcedBindingSource1;
    }
}