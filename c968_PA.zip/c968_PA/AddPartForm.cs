﻿


using Microsoft.VisualBasic.Devices;
using System.Diagnostics.Eventing.Reader;

namespace c968_PA
{
    public partial class addPartForm : Form
    {
        private bool nameGood = false;
        //private bool intGood = false;
        private bool decGood = false;
        private bool maxGood = false;
        private bool minGood = false;
        private bool companyGood = false;
        private bool minMaxCheckGood = false;
       private bool machineGood = false;
        private bool invGood = false;
        private bool invenGood = false;
        ToolTip checkMinMaxTip = new ToolTip();
        ToolTip ivenCheckTip = new ToolTip();





        public addPartForm()
        {
            InitializeComponent();
            saveButton.Enabled = false;
            idTextBox.Text = Part.GenerateNewPartID().ToString();
            idTextBox.Enabled = false;









        }
        public addPartForm(Part part2Modify)
        {
            InitializeComponent();

            addPartGroupBox.Text = "MODIFY PART";
            idTextBox.Enabled = false;
            idTextBox.Text = part2Modify.PartID.ToString();
            nameTextBox.Text = part2Modify.Name;
            inventoryTextBox.Text = part2Modify.InStock.ToString();
            priceCostTextBox.Text = part2Modify.Price.ToString();
            maxTextBox.Text = part2Modify.Max.ToString();
            minTextBox.Text = part2Modify.Min.ToString();
            saveButton.Enabled = false;
            if (part2Modify is Inhouse)
            {
                inhouseRadioButton.Checked = true;
                Inhouse inHouse2Modify = (Inhouse)part2Modify;
                machineTextBox.Text = inHouse2Modify.MachineID.ToString();

            }
            else
            {
                outsourcedRadioButton.Checked = true;
                Outsourced outsourced2Modify = (Outsourced)part2Modify;
                companyTextBox.Text = outsourced2Modify.CompanyName;

            }



        }





        private void outsourcedRadioButton_CheckedChanged(object sender, EventArgs e)
        {
           
            if (outsourcedRadioButton.Checked == true)
            {

                machineTextBox.Visible = false;
                machineLabel.Visible = false;
                machineTextBox.Text = string.Empty;

                companyTextBox.Visible = true;
                companyLabel.Visible = true;
                checkStringTextBox(companyTextBox);


            }
            else
            {

                companyTextBox.Visible = false;
                companyLabel.Visible = false;
                companyTextBox.Text = string.Empty;

                machineLabel.Visible = true;
                machineTextBox.Visible = true;
                checkIntTextBox(machineTextBox);



            }

           


        }


        private void saveButton_Click(object sender, EventArgs e)
        {


            if (addPartGroupBox.Text == "PART CLASSIFICATION")
            {

                SaveNew();

            }
            else
            {

                SaveUpdate();
            }

        }

        private void cancelButton_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void SaveNew()
        {
            if (inhouseRadioButton.Checked)
            {



                Inhouse newPart = new(int.Parse(machineTextBox.Text), int.Parse(idTextBox.Text), nameTextBox.Text, decimal.Parse(priceCostTextBox.Text), int.Parse(inventoryTextBox.Text), int.Parse(minTextBox.Text),
                    int.Parse(maxTextBox.Text));

                Inventory.AddPart(newPart);
            }

            else
            {

                Outsourced newPart = new(companyTextBox.Text, int.Parse(idTextBox.Text), nameTextBox.Text, decimal.Parse(priceCostTextBox.Text), int.Parse(inventoryTextBox.Text), int.Parse(minTextBox.Text),
                    int.Parse(maxTextBox.Text));

                Inventory.AddPart(newPart);

            }
            this.Close();
        }

        private void SaveUpdate()
        {
            if (inhouseRadioButton.Checked)
            {

                Inhouse newPart = new(int.Parse(machineTextBox.Text), int.Parse(idTextBox.Text), nameTextBox.Text, decimal.Parse(priceCostTextBox.Text), int.Parse(inventoryTextBox.Text), int.Parse(minTextBox.Text),
                   int.Parse(maxTextBox.Text));

                Inventory.UpdatePart(int.Parse(idTextBox.Text), newPart);

            }
            else
            {

                Outsourced newPart = new(companyTextBox.Text, int.Parse(idTextBox.Text), nameTextBox.Text, decimal.Parse(priceCostTextBox.Text), int.Parse(inventoryTextBox.Text), int.Parse(minTextBox.Text),
                      int.Parse(maxTextBox.Text));

                Inventory.UpdatePart(int.Parse(idTextBox.Text), newPart);
            }
            this.Close();
        }



        private bool checkStringTextBox(TextBox stringTextBox)
        {
            if ((stringTextBox.Text.Length < 1) || int.TryParse(stringTextBox.Text, out _))
            {

                stringTextBox.BackColor = Color.Red;
                return false;
            }
            else
            {
                stringTextBox.BackColor = Color.LightBlue;
                return true;
            }


        }

        private bool checkIntTextBox(TextBox intTextBox)
        {
            if (int.TryParse(intTextBox.Text, out int parsedValue) && parsedValue >= 0)
            {
                intTextBox.BackColor = Color.LightBlue;
                return true;
            }
            else
            {
                intTextBox.BackColor = Color.Red;
                return false;
            }
        }

        private bool checkDecimalTextBox(TextBox priceCostTextBox)
        {
            if (decimal.TryParse(priceCostTextBox.Text, out _))
            {
                priceCostTextBox.BackColor = Color.LightBlue;
                return true;
            }
            else
            {
                priceCostTextBox.BackColor = Color.Red;
                return false;
            }

        }

        private bool checkMinMax(TextBox maxTextBox, TextBox minTextBox)
        {

            {
                int max = int.Parse(maxTextBox.Text);
                int min = int.Parse(minTextBox.Text);



                if (max > min)
                {
                    if (checkMinMaxTip.Active)
                    {
                        checkMinMaxTip.Hide(this);
                    }
                    return true;
                    
                }
                else
                {
                    checkMinMaxTip.Show("Minimum must be LESS THAN max", this, 160, 350);
                    return false;
                }
               
            }
        }

        private void CheckEverything()
        {
            if ((nameGood && /*intGood && */invGood && decGood && minGood && maxGood && minMaxCheckGood && invenGood) && (companyGood || machineGood))
            {

                saveButton.Enabled = true;



            }
            else
            {
                saveButton.Enabled = false;

            }
        }



        private void nameTextBox_TextChanged(object sender, EventArgs e)
        {
            nameGood = checkStringTextBox(nameTextBox);
            CheckEverything();
        }

        private void priceCostTextBox_TextChanged(object sender, EventArgs e)
        {
            decGood = checkDecimalTextBox(priceCostTextBox);
            CheckEverything();
        }


        private void minTextBox_TextChanged(object sender, EventArgs e)
        {
            minGood = checkIntTextBox(minTextBox);
            if (minGood && maxGood)
            {
                minMaxCheckGood = checkMinMax(maxTextBox, minTextBox);

            }
            CheckEverything();
        }

        private void maxTextBox_TextChanged(object sender, EventArgs e)
        {
            maxGood = checkIntTextBox(maxTextBox);
            invenGood = checkInven(inventoryTextBox);
            if (minGood && maxGood)
            {
                minMaxCheckGood = checkMinMax(maxTextBox, minTextBox);

            }
            CheckEverything();

        }

        private void machineTextBox_TextChanged(object sender, EventArgs e)
        {
            machineGood = checkIntTextBox(machineTextBox);
            CheckEverything();
        }

        private void companyTextBox_TextChanged(object sender, EventArgs e)
        {
            companyGood = checkStringTextBox(companyTextBox);
            CheckEverything();
        }

        private void inventoryTextBox_TextChanged(object sender, EventArgs e)
        {
            invGood = checkIntTextBox(inventoryTextBox);
            invenGood = checkInven(inventoryTextBox);
            CheckEverything();
        }

       
        //added at last minute, im sure a lot of it is redundant but it fixed the problem so
        private void addPartForm_Load(object sender, EventArgs e)
        {
            checkDecimalTextBox(priceCostTextBox);
            checkIntTextBox(minTextBox);
            checkIntTextBox(maxTextBox);
            checkStringTextBox(nameTextBox);
            checkIntTextBox(inventoryTextBox);
            checkInven(inventoryTextBox);
            
            
            if (outsourcedRadioButton.Checked)
            {
                checkStringTextBox(companyTextBox);
            }
            else
            {
                checkIntTextBox(machineTextBox);
            }
        }
        private bool checkInven(TextBox inventoryTextBox)
        {
            if (int.TryParse(inventoryTextBox.Text, out _) && int.TryParse(maxTextBox.Text, out _))
            {
                if (int.Parse(inventoryTextBox.Text) <= int.Parse(maxTextBox.Text))
                {

                    if (ivenCheckTip.Active)
                    {
                        ivenCheckTip.Hide(this);
                    }

                    return true;
                }
                else
                {
                    ivenCheckTip.Show("Inventory must be LESS THAN OR EQUAL TO max", this, 110, 350);
                    return false;
                }
            }
            else
            {
                return false;   
            }

        }
    }
}
