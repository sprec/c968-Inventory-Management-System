﻿using System.ComponentModel;



namespace c968_PA
{
    public class Product
    {
        protected static int currID = 0;
        public  BindingList<Part> AssociatedParts { get; set; }

        public int ProductID { get; set; }

        public string Name { get; set; }

        public decimal Price { get; set; }

        public int InStock { get; set; }

        public int Min { get; set; }

        public int Max { get; set; }


        public Product(BindingList<Part> associatedParts, int productID, string name, decimal price, int inStock, int min, int max)

        {
            AssociatedParts = associatedParts;
            ProductID = productID;
            Name = name;
            Price = price;
            InStock = inStock;
            Min = min;
            Max = max;

        }

        public static int GenerateNewProductID()
        {
            return ++currID;
        }

        public void AddAssociatedPart(Part partAdding)
        {
   
            if (LookupAssociatedPart(partAdding.PartID) != null)
            {
                MessageBox.Show("Part is already integrated into product", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                AssociatedParts.Add(partAdding);
            }
        }

        public bool RemoveAssociatedPart(int partRemoving)
        {
            bool partRemoved = false;

            for(int i = 0; i < AssociatedParts.Count; i++)
            {
                if (AssociatedParts[i].PartID == partRemoving)
                {
                    AssociatedParts.RemoveAt(i);
                    return true;
                }
            }
            return partRemoved; 
        }

        public Part LookupAssociatedPart(int partLooking)
        {
            Part partLookedUp = AssociatedParts.SingleOrDefault(partSearched => partSearched.PartID == partLooking);
            
            return partLookedUp;
            

        }
    }

}
