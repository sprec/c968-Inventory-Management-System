﻿using System.ComponentModel;


namespace c968_PA
{
    public class Inventory
    {
        public static BindingList<Product> Products = new BindingList<Product>();

        public static BindingList<Part> AllParts = new BindingList<Part>();

       public static void AddProduct(Product productAdding)
        {
            Products.Add(productAdding);
        }

        public static bool RemoveProduct(int productRemoving)
        {
            bool productRemoved = false;

            for (int i = 0; i < Products.Count; i++)
            {
               
                if (Products[i].ProductID == productRemoving) {
                   
                    
                        Products.RemoveAt(i);
                        productRemoved = true;
                  
                    
                }
            }
            return productRemoved;
        }

        public static Product LookupProduct(int productLookingUp)
        {
            Product lookupResult = Products.SingleOrDefault(productSearched => productSearched.ProductID == productLookingUp);
            return lookupResult;
        }

        public static void UpdateProduct(int productUpdating, Product newProduct)
        {
           RemoveProduct(productUpdating);
           AddProduct(newProduct);
        
        }

        public static void AddPart(Part partToAdd)
        {
           
                AllParts.Add(partToAdd);
          
        }

        public static bool RemovePart(Part partRemoving)
        {
            bool partRemoved = false;

            for(int i = 0; i < AllParts.Count; i++)
            {
                if (AllParts[i].PartID == partRemoving.PartID)
                {
                    AllParts.RemoveAt(i);
                    partRemoved = true;

                }


            }

            return partRemoved;
            
        }

        public static Part LookupPart(int partLookingUp)
        {
            Part partLookedUp = AllParts.SingleOrDefault(partSearched => partSearched.PartID == partLookingUp);

            if (partLookedUp == null)
            {
                MessageBox.Show("Queried part is not found!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }

            return partLookedUp;

        }

        public static void UpdatePart(int partUpdating, Part newPart)
        {
            Part partToUpdate = LookupPart(partUpdating);
            RemovePart(partToUpdate);
            AddPart(newPart);
        }

    }
}
