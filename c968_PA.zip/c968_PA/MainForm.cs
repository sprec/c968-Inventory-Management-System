
using System.ComponentModel;


namespace c968_PA
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            partDataGridView.DataSource = Inventory.AllParts;
            productDataGridView.DataSource = Inventory.Products;


            MainForm.TestData();
            partDataGridView.ClearSelection();
            productDataGridView.ClearSelection();
        }

        private void partSearch_Click(object sender, EventArgs e)
        {
            PerformSearch(0, partSearch.Text);
        }

        private void partAddButton_Click(object sender, EventArgs e)
        {
            var addPartForm = new addPartForm();
            addPartForm.Show();
        }

        private void productSearch_Click(object sender, EventArgs e)
        {
            PerformSearch(1, productSearch.Text);
        }

        private void mainExitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void partsModifyButton_Click(object sender, EventArgs e)
        {
            Modify(0);
        }

        private void deletePartButton_Click(object sender, EventArgs e)
        {
            Delete(0);
        }

        private void productAddButton_Click(object sender, EventArgs e)
        {
            var productForm = new ProductForm();
            productForm.Show();
        }

        private void productModifyButton_Click(object sender, EventArgs e)
        {
            Modify(1);
        }

        private void productDeleteButton_Click(object sender, EventArgs e)
        {
            Delete(1);
        }

        private void partDataGridView_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Modify(0);
        }

        private void productDataGridView_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            Modify(1);
        }




        //Helpers

        private void PerformSearch(int searchBoxDesignator, string enteredText)
        {
            try
            {
                if (searchBoxDesignator == 0)
                {
                    Part partSearched = Inventory.LookupPart(int.Parse(partTextBox.Text));
                    if (partSearched != null)
                    {
                        int partSearchedID = partSearched.PartID;

                        foreach (DataGridViewRow row in partDataGridView.Rows)
                        {
                            if ((int)row.Cells["PartID"].Value == partSearchedID)
                            {
                                partDataGridView.Rows[row.Index].Selected = true;
                            }
                        }
                    }
                }
                else if (searchBoxDesignator == 1)
                {
                    Product productSearched = Inventory.LookupProduct(int.Parse(productTextBox.Text));
                    if (productSearched != null)
                    {
                        int productSearchedID = productSearched.ProductID;

                        foreach (DataGridViewRow row in productDataGridView.Rows)
                        {
                            if ((int)row.Cells["ProductID"].Value == productSearchedID)
                            {
                                productDataGridView.Rows[row.Index].Selected = true;
                            }
                        }
                    }

                }


            }
            catch (FormatException)
            {
                MessageBox.Show("Format not correct, enter ID only", "Format Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Error);
            }
        }

        private void Modify(int modifyDesignator)
        {
            try
            {
                if (modifyDesignator == 0)
                {
                    DataGridViewRow rowSelected = partDataGridView.SelectedRows[0];
                    Part part2Modify = (Part)rowSelected.DataBoundItem;
                    var modifyPartForm = new addPartForm(part2Modify);
                    modifyPartForm.Show();

                }
                else if (modifyDesignator == 1)
                {
                    DataGridViewRow rowSelected = productDataGridView.SelectedRows[0];
                    Product product2Modify = (Product)rowSelected.DataBoundItem;
                    var modifyProductForm = new ProductForm(product2Modify);
                    modifyProductForm.Show();
                }
            }
            catch (ArgumentOutOfRangeException)
            {
                MessageBox.Show("Nothing selected", "Error", MessageBoxButtons.RetryCancel, MessageBoxIcon.Warning);
            }
        }
        private void Delete(int deleteDesignator)
        {
            var deleteDialog = MessageBox.Show("You are about to delete this part or product, are you sure you wish to continue?", "WARNING", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (deleteDialog == DialogResult.Yes)
            {

                if (deleteDesignator == 0)
                {
                    DataGridViewRow rowSelected = partDataGridView.SelectedRows[0];
                    Part part2Remove = (Part)rowSelected.DataBoundItem;
                    Inventory.RemovePart(part2Remove);

                }

                else if (deleteDesignator == 1)
                {


                    DataGridViewRow rowSelected = productDataGridView.SelectedRows[0];
                    Product product2Remove = (Product)rowSelected.DataBoundItem;

                    if (product2Remove.AssociatedParts.Count < 1)
                    {
                        Inventory.RemoveProduct(product2Remove.ProductID);


                    }
                    else
                    {
                        MessageBox.Show("Product cannot be deleted", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }

                }
            }
        }

        private static void TestData()
        {
            Inhouse inHousePart1 = new Inhouse(1, Part.GenerateNewPartID(), "Tire", 200.00M, 8, 2, 20);

            Inhouse inHousePart2 = new Inhouse(2, Part.GenerateNewPartID(), "Wing", 5000.00M, 4, 2, 10);

            Outsourced outsourcedPart1 = new Outsourced("Lockheed", Part.GenerateNewPartID(), "Fuselage", 10000.00M, 3, 1, 5);

            Outsourced outsourcedPart2 = new Outsourced("General Atomics", Part.GenerateNewPartID(), "Engine", 200000.00M, 3, 1, 5);

            BindingList<Part> aLiteralAircraft = new BindingList<Part>();
            aLiteralAircraft.Add(inHousePart1);
            aLiteralAircraft.Add(inHousePart2);
            aLiteralAircraft.Add(outsourcedPart1);
            aLiteralAircraft.Add(outsourcedPart2);

            BindingList<Part> someParts = new BindingList<Part>();
            someParts.Add(inHousePart1);
            someParts.Add(outsourcedPart2);

            Inventory.AddPart(inHousePart1);
            Inventory.AddPart(inHousePart2);
            Inventory.AddPart(outsourcedPart1);
            Inventory.AddPart(outsourcedPart2);


            Product aVeryCheapButSafePlane = new Product(aLiteralAircraft, Product.GenerateNewProductID(), "Totally Safe Plane", 800000.00M, 1, 1, 3);
            Inventory.AddProduct(aVeryCheapButSafePlane);

            Product aNotSoSafePlane = new Product(someParts, Product.GenerateNewProductID(), "Not So Safe Plane", 100000.00M, 2, 2, 3);
            Inventory.AddProduct(aNotSoSafePlane);

        }

        private void partTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;

                PerformSearch(0, partSearch.Text);

            }
        }

        private void productTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter)
            {

                e.Handled = true;

                PerformSearch(1, productSearch.Text);

            }
        }

    }

}
